'use strict';

const Controller = require('egg').Controller;
const puppeteer = require('puppeteer-extra');
const dappeteerc = require('@chainsafe/dappeteer');
const {
  getBrowserInstance
} = require('../utils/instance.js');

class HomeController extends Controller {
  async index() {
    const ctx = this.ctx;
    const { dappeteer,page } = await getBrowserInstance();
    // const { dappeteer,page } = await dappeteerc.bootstrap(puppeteer, { seed:'cousin tackle inner repeat auction wheat silly pole series chase monster one',password:'123456',showTestNets:false,metaMaskVersion: 'v10.20.0' }); 
    await page.bringToFront()
    const header = await page.$('.section-header');
    if (header.element === null) {
      // 签名及授权
      await this.ApproveAndSign(page,dappeteer)
    }
    await new Promise(resolve => setTimeout(resolve, 1000));
    const response = await page.evaluate(() => {
      return fetch("https://core-api.prod.blur.io/v1/buy/0x410adce627311feee1e285f85e8ca4bd290c9062",{
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": "{\"tokenPrices\":[{\"tokenId\":\"1324\",\"price\":{\"amount\":\"0.0001\",\"unit\":\"ETH\"}}],\"userAddress\":\"0x8e9bad8c895c4e812f53eb98fcf40a9e45145f99\"}",
        //"body": "{\"tokenPrices\":[{\"tokenId\":\"543\",\"price\":{\"amount\":\"0.00798\",\"unit\":\"ETH\"}}],\"userAddress\":\"0x8e9BAd8C895C4e812f53eB98FCF40A9E45145F99\"}",
        "credentials": "include"
      }).then(response => response.json());
    });
    console.log(response)
    if(response.success){
      ctx.body = response 
    }
  }
    async getOrderCreate(){
      const ctx = this.ctx;
      const { dappeteer,page } = await getBrowserInstance();
      await page.bringToFront()
      const header = await page.$('.section-header');
      if (header.element === null) {
        // 签名及授权
        await this.ApproveAndSign(page,dappeteer)
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
      const response = await page.evaluate(() => {
        return fetch("https://core-api.prod.blur.io/v1/activity?filters={%22count%22:50,%22eventTypes%22:[%22ORDER_CREATED%22]}",{
          "method": "GET",
          "headers": {
              "Content-Type": "application/json"
          },
          "credentials": "include"
        }).then(response => response.json());
      });
      ctx.body = response
    }
    async ApproveAndSign(page,dappeteer){
      await page.goto('https://blur.io/collections');  
      await new Promise(resolve => setTimeout(resolve, 2000)); 
      let divHandle = await page.$('.hfNjKR')
      console.log(divHandle)
      await divHandle.click();
      let METAMASKHandle = await page.$('#METAMASK')
      await new Promise(resolve => setTimeout(resolve, 1000)); 
      await METAMASKHandle.click();
      await dappeteer.approve(page)
      await new Promise(resolve => setTimeout(resolve, 1000)); 
      await page.bringToFront()
      await new Promise(resolve => setTimeout(resolve, 1000));
      await dappeteer.sign()
      await new Promise(resolve => setTimeout(resolve, 2000));
      await page.bringToFront()
    }
    // 防止被腾讯检测
    async setBrowserPage(page) {
      // 设置user_agent
      await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4181.9 Safari/537.36")
      // 设置webdriver
      await page.evaluateOnNewDocument(() => {
        Object.defineProperty(navigator, 'webdriver', {
          get: () => false
        });
        Object.defineProperty(navigator, 'plugins', {
          get: () => [{
              0: {
                type: "application/x-google-chrome-pdf",
                suffixes: "pdf",
                description: "Portable Document Format"
              },
              description: "Portable Document Format",
              filename: "internal-pdf-viewer",
              length: 1,
              name: "Chrome PDF Plugin"
            },
            {
              0: {
                type: "application/pdf",
                suffixes: "pdf",
                description: ""
              },
              description: "",
              filename: "mhjfbmdgcfjbbpaeojofohoefgiehjai",
              length: 1,
              name: "Chrome PDF Viewer"
            },
            {
              0: {
                type: "application/x-nacl",
                suffixes: "",
                description: "Native Client Executable"
              },
              1: {
                type: "application/x-pnacl",
                suffixes: "",
                description: "Portable Native Client Executable"
              },
              description: "",
              filename: "internal-nacl-plugin",
              length: 2,
              name: "Native Client"
            }
          ],
        });
      });
      await page.evaluateOnNewDocument(() => {
        window.navigator.chrome = {
          runtime: {},
          loadTimes: function () {},
          csi: function () {},
          app: {}
        };
      });
      await page.evaluateOnNewDocument(() => {
        window.navigator.language = {
          runtime: {},
          loadTimes: function () {},
          csi: function () {},
          app: {}
        };
      });
    }
}

module.exports = HomeController;
