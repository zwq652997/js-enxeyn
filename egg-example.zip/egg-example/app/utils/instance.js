const pptr = require('puppeteer');


const puppeteer = require('puppeteer-extra');
const dappeteerc = require('@chainsafe/dappeteer');

let instance = null;
module.exports.getBrowserInstance = async function () {
    if (!instance) {
        instance = await dappeteerc.bootstrap(puppeteer); 
    }
    return instance;
}